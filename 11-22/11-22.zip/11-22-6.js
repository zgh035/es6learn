



//codePointAt

let s = '𠮷a';

s.codePointAt(0);